﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Staff_Details : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                populateGridView();

            }
        }

        void populateGridView()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(cs))
            {
                
                SqlCommand cmd = new SqlCommand("select * from TBLSTAFF", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                 }
            if (dt.Rows.Count > 0)
            {
                gvStaffid.DataSource = dt;
                gvStaffid.DataBind();
            }
            else
            {
                dt.Rows.Add(dt.NewRow());
                gvStaffid.DataSource = dt;
                gvStaffid.DataBind();
                gvStaffid.Rows[0].Cells.Clear();
                gvStaffid.Rows[0].Cells.Add(new TableCell());
                gvStaffid.Rows[0].Cells[0].ColumnSpan = dt.Columns.Count;
                gvStaffid.Rows[0].Cells[0].Text = "no Data Found";
                gvStaffid.Rows[0].Cells[0].HorizontalAlign = HorizontalAlign.Center;
            }
        }

        protected void gvStaffid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.Equals("Add"))
                {
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        string Query = "INSERT INTO TBLSTAFF (First_Name,Last_Name,Email,Phone,Activec) VALUES (@First_Name,@Last_Name,@Email,@Phone,@Activec)";
                        con.Open();
                        SqlCommand cmd = new SqlCommand(Query, con);
                        cmd.Parameters.AddWithValue("@First_Name", (gvStaffid.FooterRow.FindControl("txtFNameF") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Last_Name", (gvStaffid.FooterRow.FindControl("txtLNameF") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Email", (gvStaffid.FooterRow.FindControl("txtEmailF") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Phone", (gvStaffid.FooterRow.FindControl("txtPhoneF") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Activec", (gvStaffid.FooterRow.FindControl("txtActiveF") as TextBox).Text.Trim());
                        cmd.ExecuteNonQuery();
                        populateGridView();
                        lblSMesg.Text = "New Record Added";


                    }
                }
            }
            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }

        protected void gvStaffid_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvStaffid.EditIndex = e.NewEditIndex;
            populateGridView();
        }

        protected void gvStaffid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvStaffid.EditIndex = -1;
            populateGridView();
        }

        protected void gvStaffid_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                    {
                        string Query = "UPDATE TBLSTAFF SET First_Name=@First_Name,Last_Name=@Last_Name,Email=@Email,Phone=@Phone,Activec=@Activec WHERE Staff_ID=@id";
                        con.Open();
                        SqlCommand cmd = new SqlCommand(Query, con);
                        cmd.Parameters.AddWithValue("@First_Name", (gvStaffid.Rows[e.RowIndex].FindControl("txtFName") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Last_Name", (gvStaffid.Rows[e.RowIndex].FindControl("txtLName") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Email", (gvStaffid.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Phone", (gvStaffid.Rows[e.RowIndex].FindControl("txtPhone") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@Activec", (gvStaffid.Rows[e.RowIndex].FindControl("txtActive") as TextBox).Text.Trim());
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(gvStaffid.DataKeys[e.RowIndex].Value.ToString()));
                        cmd.ExecuteNonQuery();
                        gvStaffid.EditIndex = -1;
                        populateGridView();
                        lblSMesg.Text = "Selected Recorded Update";


                    }
                }
            
            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }

        protected void gvStaffid_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "DELETE FROM TBLSTAFF WHERE Staff_ID=@id";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(gvStaffid.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                
                    populateGridView();
                    lblSMesg.Text = "Selected Recorded Deleted";


                }
            }

            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }
    }
}