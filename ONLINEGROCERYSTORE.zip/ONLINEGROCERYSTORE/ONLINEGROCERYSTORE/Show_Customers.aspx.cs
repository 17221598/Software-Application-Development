﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Show_Customers : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                populateGridView();

            }
        }

        private void populateGridView()
        {
            DataTable dt = new DataTable();
             using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from TBLCUSTOMERS", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
            }
             GVCustomers.DataSource = dt;
             GVCustomers.DataBind();

        }

        protected void GVCustomers_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GVCustomers.EditIndex = e.NewEditIndex;
            populateGridView();
        }

        protected void GVCustomers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GVCustomers.EditIndex = -1;
            populateGridView();
        }

        protected void GVCustomers_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "UPDATE TBLCUSTOMERS SET First_Name=@First_Name,Last_Name=@Last_Name,Email=@Email,Phone=@Phone,State=@State,City=@City,PostalCode=@PostalCode WHERE Customer_ID=@Customer_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@First_Name", (GVCustomers.Rows[e.RowIndex].FindControl("txtFName") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Last_Name", (GVCustomers.Rows[e.RowIndex].FindControl("txtLName") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", (GVCustomers.Rows[e.RowIndex].FindControl("txtEmail") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", (GVCustomers.Rows[e.RowIndex].FindControl("txtPhone") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@State", (GVCustomers.Rows[e.RowIndex].FindControl("txtState") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@City", (GVCustomers.Rows[e.RowIndex].FindControl("txtCity") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@PostalCode", (GVCustomers.Rows[e.RowIndex].FindControl("txtPostalCode") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Customer_ID", Convert.ToInt32(GVCustomers.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    GVCustomers.EditIndex = -1;
                    populateGridView();
                    lblSMesg.Text = "Selected Recorded Update";
                }
            }
            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            } }

        protected void GVCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "DELETE FROM TBLCUSTOMERS WHERE Customer_ID=@Customer_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Customer_ID", Convert.ToInt32(GVCustomers.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    populateGridView();
                    lblSMesg.Text = "Selected Recorded Deleted";


                }
            }

            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }

    }
}