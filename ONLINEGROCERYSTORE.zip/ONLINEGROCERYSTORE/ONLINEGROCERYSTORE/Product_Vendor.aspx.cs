﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Product_Vendor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("insert into TBLVENDORS values('" + VendName.Text + "', '"+ VendPhone.Text+"','" +VendQuantity.Text+"', '" +VendInventory.Text+"', '"+VendRevenue.Text+"')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                VendName.Text = string.Empty;
                VendPhone.Text = string.Empty;
                VendQuantity.Text = string.Empty;
                VendInventory.Text = string.Empty;
                VendRevenue.Text = string.Empty;

                Response.Redirect("~/ShowProductVendors.aspx");
            }

        }
    }
        }
    