﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;

namespace ONLINEGROCERYSTORE
{
    public partial class Shipper_Details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Ship_Click(object sender, EventArgs e)
        {
            String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("insert into TBLSHIPPER values('" + ShipName.Text + "', '" + ShipPhone.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                ShipName.Text = string.Empty;
                ShipPhone.Text = string.Empty;
            }
        }
    }
}