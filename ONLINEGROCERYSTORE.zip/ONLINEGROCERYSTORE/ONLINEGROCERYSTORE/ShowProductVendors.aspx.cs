﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class ShowProductVendors : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindproductRept();

            }
        }

        private void BindproductRept()
        {
            String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TBLVENDORS", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtCat = new DataTable();
                        sda.Fill(dtCat);
                        GVPVendor.DataSource = dtCat;
                        GVPVendor.DataBind();

                    }
                }
            }
        }

        protected void GVPVendor_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GVPVendor.EditIndex = e.NewEditIndex;
            BindproductRept();

        }

        protected void GVPVendor_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GVPVendor.EditIndex = -1;
            BindproductRept();
        }

        protected void GVPVendor_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "UPDATE TBLVENDORS SET Vendor_Name=@Vendor_Name,Phone=@Phone,Product_Quantity=@Product_Quantity,Inventory_Worth=@Inventory_Worth,Revenue_Gen=@Revenue_Gen WHERE Vendor_ID=@Vendor_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Vendor_Name", (GVPVendor.Rows[e.RowIndex].FindControl("txtVName") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", (GVPVendor.Rows[e.RowIndex].FindControl("txtPhone") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Product_Quantity", (GVPVendor.Rows[e.RowIndex].FindControl("txtPQuantity") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Inventory_Worth", (GVPVendor.Rows[e.RowIndex].FindControl("txtIWorth") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Revenue_Gen", (GVPVendor.Rows[e.RowIndex].FindControl("txtRGen") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Vendor_ID", Convert.ToInt32(GVPVendor.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    GVPVendor.EditIndex = -1;
                    BindproductRept();
                    lblSMesg.Text = "Selected Recorded Update";
                }
            }
            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }

        protected void GVPVendor_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }
    }
}