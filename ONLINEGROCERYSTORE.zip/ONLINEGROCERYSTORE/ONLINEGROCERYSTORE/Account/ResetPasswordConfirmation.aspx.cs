﻿using System.Web.UI;

namespace ONLINEGROCERYSTORE.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}