﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;
using System.Net.Mail;
using System.Net;
namespace ONLINEGROCERYSTORE
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["User_Name"] != null && Request.Cookies["Password"] != null)
                {
                    UName.Text = Request.Cookies["User_Name"].Value;
                    Password.Attributes["value"] = Request.Cookies["Password"].Value;
                    RememberMe.Checked = true;

                }
            }

        }

        protected void btnSignin_Click(object sender, EventArgs e)
        {
               String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
               using (SqlConnection con = new SqlConnection(cs))
               {
                   SqlCommand cmd = new SqlCommand("select * from SignUp where User_Name='" + UName.Text + "' and Password='" + Password.Text + "'", con);
                   con.Open();
                   SqlDataAdapter sda = new SqlDataAdapter(cmd);
                   DataTable dt = new DataTable();
                    sda.Fill(dt);

                   if (dt.Rows.Count != 0)
                   {
                       if (RememberMe.Checked)
                       {
                           Response.Cookies["User_Name"].Value = UName.Text;
                           Response.Cookies["PASSWORD "].Value = Password.Text;
                           Response.Cookies["User_Name"].Expires = DateTime.Now.AddDays(20);
                           Response.Cookies["PASSWORD"].Expires = DateTime.Now.AddDays(20);
                          

                       }
                       else
                       {
                           Response.Cookies["User_Name"].Expires = DateTime.Now.AddDays(-1);
                           Response.Cookies["PASSWORD"].Expires = DateTime.Now.AddDays(-1);
                       }

                       String UType;
                       UType = dt.Rows[0][5].ToString().Trim();
                       if (UType == "U")
                       {
                           Session["User_Name"] = UName.Text;
                           Response.Redirect("~/User/Home.aspx");
                       }
                       if (UType == "A")
                       {
                           Session["User_Name"] = UName.Text;
                           Response.Redirect ("~/Sales.aspx");
                       }    
                    

                   }
                   else
                   {
                       lblMess.Text = "UserName and password did not match";
                       lblMess.ForeColor = Color.Red;
                   }

               }
        }
    }
}