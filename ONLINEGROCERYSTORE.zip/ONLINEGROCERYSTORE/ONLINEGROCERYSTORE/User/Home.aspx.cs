﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ONLINEGROCERYSTORE.User
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User_Name"] != null)
            {
                lblMess.Text = "Login Successfull, Welcome::" + Session["User_Name"].ToString() + "";
            }
            else
            {
                Response.Redirect("~/User/Login.aspx");
            }
        }
    }
}