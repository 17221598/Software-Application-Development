﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
namespace ONLINEGROCERYSTORE.User
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed13_Click(object sender, EventArgs e)
        {
            if (Name.Text != "" & UName.Text != "" & Password.Text != "" & ConfirmPassword.Text != "" & Email.Text != "")
            {
                if (Password.Text == ConfirmPassword.Text) {
                    String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(cs))
                    {
                        SqlCommand cmd = new SqlCommand("insert into SignUp values('" + Name.Text + "','" + UName.Text + "','" + Password.Text + "','" + Email.Text + "','U')", con);
                        con.Open();
                        cmd.ExecuteNonQuery();
                        lblErr.Text = "Registration is Successfull";
                        lblErr.ForeColor = Color.Green;
                        Response.Redirect("~/User/Login.aspx");
                    }
                }
                else
                {
                    lblErr.ForeColor = Color.Red;
                    lblErr.Text = "Password and conform password did not match";
                }
                
             }
            else
            {
                lblErr.ForeColor = Color.Red;
                lblErr.Text = "All Fields are required";
            }

        }
    }
}