﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Customers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("insert into TBLCUSTOMERS values('" + FName.Text + "', '" + LName.Text + "','" + Email.Text + "', '" + Phone.Text + "', '" + TState.Text + "','" + City.Text + "', '" + PostalCode.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                FName.Text = string.Empty;
                LName.Text = string.Empty;
                Email.Text = string.Empty;
                Phone.Text = string.Empty;
                TState.Text = string.Empty;
                City.Text = string.Empty;
                PostalCode.Text = string.Empty;
               
                Response.Redirect("~/Show_Customers");
               
                
            }

        }
    }
}