﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Order : System.Web.UI.Page
    {
      public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCustomers();
                BindShipment();
            }
        }

        private void BindShipment()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from TBLSHIPPER", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count != 0)
                {
                    ddlSD.DataSource = dt;
                    ddlSD.DataTextField = "Company_Name";
                    ddlSD.DataValueField = "Shipper_ID";
                    ddlSD.DataBind();
                    ddlSD.Items.Insert(0, new ListItem("-Select-", "0"));
                }
            }
        }

        private void BindCustomers()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from TBLCUSTOMERS", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count != 0)
                {
                    ddlCust.DataSource = dt;
                    ddlCust.DataTextField = "First_Name";
                    ddlCust.DataValueField = "Customer_ID";
                    ddlCust.DataBind();
                    ddlCust.Items.Insert(0, new ListItem("-Select-", "0"));
                }
            }
        }

        protected void Orders_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("insert into TBLORDER(Customer_ID,Shipper_ID,Order_Number,Ship_Date,Required_Date,Order_date) values('" + ddlCust.SelectedItem.Value + "','" + ddlSD.SelectedItem.Value + "','" + txtOID.Text + "','" + txtSDT.Text + "','" + txtRSD.Text + "', '" + txtOD.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                ddlCust.ClearSelection();
                ddlSD.ClearSelection();
                txtOID.Text = string.Empty;
                txtSDT.Text = string.Empty;
                txtRSD.Text = string.Empty;
                txtOD.Text = string.Empty;

            }
        }
    }
}