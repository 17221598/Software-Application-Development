﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Product_Category : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindCategoryRept();

            }
        }

        private void BindCategoryRept()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("select * from TBLCATEGORY", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtCat = new DataTable();
                        sda.Fill(dtCat);
                        GVCategory.DataSource = dtCat;
                        GVCategory.DataBind();

                    }
                }
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("insert into TBLCATEGORY values('" + CatName.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                CatName.Text = string.Empty;
                BindCategoryRept();

            }

        }

        protected void GVCategory_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GVCategory.EditIndex = e.NewEditIndex;
            BindCategoryRept();
        }

        protected void GVCategory_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GVCategory.EditIndex = -1;
            BindCategoryRept();
        }

        protected void GVCategory_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "UPDATE TBLCATEGORY SET Category_Name=@Category_Name WHERE Category_ID=@Category_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Category_Name", (GVCategory.Rows[e.RowIndex].FindControl("txtCName") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Category_ID", Convert.ToInt32(GVCategory.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    GVCategory.EditIndex = -1;
                    BindCategoryRept();
                    lblSMesg.Text = "Selected Recorded Update";
                }
            }
            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }

        protected void GVCategory_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "DELETE FROM TBLCATEGORY WHERE Category_ID=@Category_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Brand_ID", Convert.ToInt32(GVCategory.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    BindCategoryRept();
                    lblSMesg.Text = "Selected Recorded Deleted";


                }
            }

            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }
    }
}