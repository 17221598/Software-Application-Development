﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Product_Brand : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
          if  (!IsPostBack){
              BindBrandsRept();

            }

        }

        private void BindBrandsRept()

        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                using (SqlCommand cmd = new SqlCommand("select * from tblBrands", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dtBrand = new DataTable();
                        sda.Fill(dtBrand);
                        GVBrand.DataSource = dtBrand;
                        GVBrand.DataBind();

              }
                }
            }
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
                using (SqlConnection con = new SqlConnection(cs))
                {
                    SqlCommand cmd = new SqlCommand("insert into tblBrands values('" + Name.Text + "')", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    Name.Text = string.Empty;
                    BindBrandsRept();

                }

            }
            catch (Exception ex)
            {
                
                  lblSErr.Text = ex.Message;
            }
        }

        protected void GVBrand_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GVBrand.EditIndex = e.NewEditIndex;
            BindBrandsRept();
        }

        protected void GVBrand_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GVBrand.EditIndex = -1;
            BindBrandsRept();
        }

        protected void GVBrand_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "UPDATE tblBrands SET Brand_Name=@Brand_Name WHERE Brand_ID=@Brand_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Brand_Name", (GVBrand.Rows[e.RowIndex].FindControl("txtBName") as TextBox).Text.Trim());
                   
                    cmd.Parameters.AddWithValue("@Brand_ID", Convert.ToInt32(GVBrand.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    GVBrand.EditIndex = -1;
                    BindBrandsRept();
                    lblSMesg.Text = "Selected Recorded Update";
                }
            }
            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }

        protected void GVBrand_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "DELETE FROM tblBrands WHERE Brand_ID=@Brand_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Brand_ID", Convert.ToInt32(GVBrand.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    BindBrandsRept();
                    lblSMesg.Text = "Selected Recorded Deleted";


                }
            }

            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }
 
    }
}