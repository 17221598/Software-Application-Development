﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Sale_Details : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                populateGridView();

            }
        }

        private void populateGridView()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from TBLSALE", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
            }
            GVSDetails.DataSource = dt;
            GVSDetails.DataBind();
        }

        protected void GVSDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GVSDetails.EditIndex = e.NewEditIndex;
            populateGridView();
        }

        protected void GVSDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GVSDetails.EditIndex = -1;
            populateGridView();
        }

        protected void GVSDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
                        try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "UPDATE TBLSALE SET Price=@Price,Date=@Date,Description=@Description WHERE Sale_ID=@Sale_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    //cmd.Parameters.AddWithValue("@Product_ID", (GVSDetails.Rows[e.RowIndex].FindControl("txtFName") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Price", (GVSDetails.Rows[e.RowIndex].FindControl("txtSP") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Date", (GVSDetails.Rows[e.RowIndex].FindControl("txtSD") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Description", (GVSDetails.Rows[e.RowIndex].FindControl("txtSDE") as TextBox).Text.Trim());
                    cmd.Parameters.AddWithValue("@Sale_ID", Convert.ToInt32(GVSDetails.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    GVSDetails.EditIndex = -1;
                    populateGridView();
                    lblSMesg.Text = "Selected Recorded Update";
                }
            }
            catch (Exception ex)
                        {

                            lblSErr.Text = ex.Message;
                        }
        }

        protected void GVSDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(cs))
                {
                    string Query = "DELETE FROM TBLCUSTOMERS WHERE Sale_ID=@Sale_ID";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(Query, con);
                    cmd.Parameters.AddWithValue("@Sale_ID", Convert.ToInt32(GVSDetails.DataKeys[e.RowIndex].Value.ToString()));
                    cmd.ExecuteNonQuery();
                    populateGridView();
                    lblSMesg.Text = "Selected Recorded Deleted";


                }
            }

            catch (Exception ex)
            {

                lblSErr.Text = ex.Message;
            }
        }
    }
}