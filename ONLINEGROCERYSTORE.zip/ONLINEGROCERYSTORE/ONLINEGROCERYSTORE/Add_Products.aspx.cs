﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;

namespace ONLINEGROCERYSTORE
{
    public partial class Add_Products : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["GroceryStoreConnectionString1"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindBrands();
                BindCategory();
                BindVendors();
            }
        }

        private void BindVendors()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from TBLVENDORS", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count != 0)
                {
                    ddlPVendor.DataSource = dt;
                    ddlPVendor.DataTextField = "Vendor_Name";
                    ddlPVendor.DataValueField = "Vendor_ID";
                    ddlPVendor.DataBind();
                    ddlPVendor.Items.Insert(0, new ListItem("-Select-", "0"));
                }
            }
        }

        private void BindCategory()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from TBLCATEGORY", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count != 0)
                {
                    ddlPCat.DataSource = dt;
                    ddlPCat.DataTextField = "Category_Name";
                    ddlPCat.DataValueField = "Category_ID";
                    ddlPCat.DataBind();
                    ddlPCat.Items.Insert(0, new ListItem("-Select-", "0"));
                }
            }
        }

        private void BindBrands()
        {
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("select * from tblBrands", con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count != 0)
                {
                    ddlPBrand.DataSource = dt;
                    ddlPBrand.DataTextField = "Brand_Name";
                    ddlPBrand.DataValueField = "Brand_ID";
                    ddlPBrand.DataBind();
                    ddlPBrand.Items.Insert(0, new ListItem("-Select-", "0"));
                }
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            using (SqlConnection con = new SqlConnection(cs))

            {
                SqlCommand cmd = new SqlCommand("insert into TBLPRODUCT(Product_Name,Category_ID,Brand_ID,Vendor_ID,Product_Price,Selling_Price,Description) values('" + txtProName.Text + "','" + ddlPCat.SelectedItem.Value + "','" + ddlPBrand.SelectedItem.Value + "','" + ddlPVendor.SelectedItem.Value + "','" + txbprice.Text + "','" + txtSprice.Text + "', '" + txtDec.Text + "')", con);
                con.Open();
                cmd.ExecuteNonQuery();
                txtProName.Text = string.Empty;
                ddlPCat.ClearSelection();
                ddlPBrand.ClearSelection();
                ddlPVendor.ClearSelection();
                txbprice.Text = string.Empty;
                txtSprice.Text = string.Empty;
                txtDec.Text = string.Empty;







            }



        }
    }
}